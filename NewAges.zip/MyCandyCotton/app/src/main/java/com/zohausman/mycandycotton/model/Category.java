package com.zohausman.mycandycotton.model;

public class Category {


    private String id;
    private String catname;
    private String image;
    private String sdesc;
    private String status;

    public Category() {
    }

    public Category(String id, String catname, String image, String sdesc, String status) {
        this.id = id;
        this.catname = catname;
        this.image = image;
        this.sdesc = sdesc;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCatname() {
        return catname;
    }

    public void setCatname(String catname) {
        this.catname = catname;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getSdesc() {
        return sdesc;
    }

    public void setSdesc(String sdesc) {
        this.sdesc = sdesc;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
