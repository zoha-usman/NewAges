package com.zohausman.mycandycotton.Utils;

public class Constants {
    public static String base64Image="";
    public static String uuid="";
}
