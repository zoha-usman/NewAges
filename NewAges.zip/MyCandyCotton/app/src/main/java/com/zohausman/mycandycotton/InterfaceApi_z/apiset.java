package com.zohausman.mycandycotton.InterfaceApi_z;

import com.zohausman.mycandycotton.model.ApiResponseProfileUPdate;
import com.zohausman.mycandycotton.model.ShowAllCat;
import com.zohausman.mycandycotton.model.Showall;
import com.zohausman.mycandycotton.model.index_response_model;
import com.zohausman.mycandycotton.model.login_response_model;
import com.zohausman.mycandycotton.model.orderApiResponse;
import com.zohausman.mycandycotton.model.orderResponse;
import com.zohausman.mycandycotton.model.profile_pic_update;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface apiset {


    @FormUrlEncoded
    @POST("index.php?action=signup")
    Call<index_response_model> getregister(
            @Field("name") String name,
            @Field("email") String email,
            @Field("password") String password);

    @FormUrlEncoded
    @POST("index.php?action=login")
    Call<login_response_model> getlogin(@Field("email") String email, @Field("password") String password);



        @GET("index.php?action=show_products")
        Call<Showall> getProducts();

        @GET("index.php?action=show_all_Categories")
        Call<ShowAllCat>  getAllCategories();


    @GET("index.php?action=products_by_category")
    Call<Showall> getProductsByCategory(@Query("category") String categoryName);

    @GET("index.php?action=show_products&category=new_arrivals_products&limit=5")
    Call<Showall> getNewArrivalProducts(
            @Query("category") String categoryName,
            @Query("limit") int limit
    );

    @FormUrlEncoded
    @POST("index.php?action=update_user_profile")
    Call<ApiResponseProfileUPdate> checkProfileUpdate(
            @Field("user_id") String userId,
            @Field("name") String name,
            @Field("email") String email,
            @Field("password") String password,
            @Field("address") String address,
            @Field("city") String city,
            @Field("contact") String contact
    );

    @Multipart
    @POST("index.php")
    Call<profile_pic_update> upload(
            @Part("action") RequestBody action,
            @Part("user_id") RequestBody user_id,
            @Part MultipartBody.Part img
    );

    @FormUrlEncoded
    @POST("index.php")
    Call<orderApiResponse> placeOrder(
            @Field("action") String action,
            @Field("user_id") String userId,
            @Field("user_name") String userName,
            @Field("useremail") String userEmail,
            @Field("user_phone") String userPhone,
            @Field("user_address") String userAddress,
            @Field("user_id") String userID,
            @Field("order_id") int orderId,
            @Field("product_id[]") int[] productIds,
            @Field("size[]") String[] sizes,
            @Field("qty[]") int[] quantities,
            @Field("price[]") double[] prices,
            @Field("sub_total[]") double[] subTotals
    );

    @GET("index.php")
    Call<orderResponse> showOrderDetails(
            @Query("action") String action,
            @Query("user_id") String userId);

}
