package com.zohausman.mycandycotton.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.hishd.tinycart.model.Cart;
import com.hishd.tinycart.model.Item;
import com.hishd.tinycart.util.TinyCartHelper;
import com.zohausman.mycandycotton.R;


import com.zohausman.mycandycotton.adapter.CartAdapter;
import com.zohausman.mycandycotton.databinding.ActivityWishListBinding;
import com.zohausman.mycandycotton.model.Product;
import com.zohausman.mycandycotton.model.productDispData;

import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

public class WishListActivity extends AppCompatActivity {
    ActivityWishListBinding binding;
    CartAdapter adapter;
    ArrayList<productDispData> products;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWishListBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


//        adapter = new CartAdapter(this, products, new CartAdapter.CartListener() {
//            @Override
//            public void onQuantityChanged() {
//                binding.subtotal.setText(String.format("PKR %.2f", cart.getTotalPrice()));
//            }
//        });



        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        products = new ArrayList<>();
        Cart cart = TinyCartHelper.getCart();
        for(Map.Entry<Item,Integer> item: cart.getAllItemsWithQty().entrySet()){
            productDispData product = (productDispData) item.getKey();
            int quantity = item.getValue();
            product.setQuantity(String.valueOf(quantity));

//            products.add(products);

        };

//        setContentView(R.layout.activity_wish_list);
        binding.btnWishListCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();

            }
        });


        binding.btnWishListShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder shareText = new StringBuilder();
                for (productDispData product : products) {
                    shareText.append(product.getPname())
                            .append("\nPrice: ")
                            .append(product.getPrice())
                            .append("\n");

                    // Append image URL if available
//                    if (product.getImageUrl() != null && !product.getImageUrl().isEmpty()) {
//                        shareText.append("Image: ")
//                                .append(product.getImageUrl())
//                                .append("\n");
//                    }



                    shareText.append("\n");
                }

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareText.toString());
                startActivity(Intent.createChooser(shareIntent, "Share via"));


//                    Intent iShare = new Intent(Intent.ACTION_SEND);
//                    iShare.setType("Text/Plain");
//                    iShare.putExtra(Intent.EXTRA_TEXT, "");
//                    startActivity(Intent.createChooser(iShare,"Share"));
            }
        });

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        DividerItemDecoration itemDecoration= new DividerItemDecoration(this, layoutManager.getOrientation());
//        binding.cartList.setLayoutManager(layoutManager);
//        binding.cartList.addItemDecoration(itemDecoration);
//        binding.cartList.setAdapter(adapter);


    }

}