package com.zohausman.mycandycotton.model;

public class ShowAllUser {

    public String msg;
    public boolean sts;
    public String action;
//    public ArrayList<UserDetail> data;
}
