package com.zohausman.mycandycotton.model;

import java.util.ArrayList;

public class orderResponse {
    public String msg;
    public boolean sts;
    public String action;
    public ArrayList<OrderDataResponseModel> data;

    public orderResponse() {
    }

    public orderResponse(String msg, boolean sts, String action, ArrayList<OrderDataResponseModel> data) {
        this.msg = msg;
        this.sts = sts;
        this.action = action;
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isSts() {
        return sts;
    }

    public void setSts(boolean sts) {
        this.sts = sts;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public ArrayList<OrderDataResponseModel> getData() {
        return data;
    }

    public void setData(ArrayList<OrderDataResponseModel> data) {
        this.data = data;
    }

}
