package com.zohausman.mycandycotton.activities;

import androidx.appcompat.app.AppCompatActivity;
import com.zohausman.mycandycotton.R;
import com.zohausman.mycandycotton.databinding.ActivityOrderSuccessBinding;


import android.content.Intent;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;

public class OrderSuccessActivity extends AppCompatActivity {
   ActivityOrderSuccessBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityOrderSuccessBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.btnHomeScreen.setOnClickListener(v -> {
            Intent intent = new Intent(OrderSuccessActivity.this, DashBoard.class);
            startActivity(intent);
        });

        binding.BtnHistoryOrder.setOnClickListener(v->{
            Intent intent = new Intent(OrderSuccessActivity.this, OrderDetailActivity.class);
            startActivity(intent);
        });
//        setContentView(R.layout.activity_order_success);





    }
}