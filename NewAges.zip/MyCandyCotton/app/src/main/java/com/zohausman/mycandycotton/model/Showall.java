package com.zohausman.mycandycotton.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Showall {

    @SerializedName("data")
    public ArrayList<productDispData> data;

    public String msg;
    public boolean sts;
    public String action;

    public Showall() {
    }

    public Showall(String msg, boolean sts, String action, ArrayList<productDispData> data) {
        this.msg = msg;
        this.sts = sts;
        this.action = action;
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isSts() {
        return sts;
    }

    public void setSts(boolean sts) {
        this.sts = sts;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public ArrayList<productDispData> getData() {
        return data;
    }

    public void setData(ArrayList<productDispData> data) {
        this.data = data;
    }
}

