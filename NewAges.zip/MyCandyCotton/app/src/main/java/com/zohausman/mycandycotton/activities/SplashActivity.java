package com.zohausman.mycandycotton.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.slider.Slider;
import com.zohausman.mycandycotton.R;

public class SplashActivity extends AppCompatActivity {
    ImageView imageView;
   TextView nameview, Dis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);


        imageView = findViewById(R.id.imageView);
        nameview = findViewById(R.id.nameView);
        Dis= findViewById(R.id.disText);


        AlphaAnimation animation = new AlphaAnimation(0.0f, 1.0f);
        animation.setDuration(2000); // duration in milliseconds
        imageView.setVisibility(View.VISIBLE);
        imageView.startAnimation(animation);

        //animation on text

      nameview.setVisibility(View.VISIBLE);
      nameview.startAnimation(animation);

      Dis.setVisibility(View.VISIBLE);
      Dis.startAnimation(animation);

        Intent intent = new Intent(SplashActivity.this, SliderActivity.class);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(intent);
            }
        } ,3000);
    }
}