package com.zohausman.mycandycotton.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.bumptech.glide.Glide;
import com.zohausman.mycandycotton.activities.ProductDetailActivity;
import com.zohausman.mycandycotton.databinding.ItemProductBinding;
import com.zohausman.mycandycotton.model.Product;
import com.zohausman.mycandycotton.R;
import com.zohausman.mycandycotton.model.Showall;
import com.zohausman.mycandycotton.model.productDispData;

import java.util.ArrayList;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    Context context;
    List<productDispData> productList;

    public ProductAdapter(Context context, List<productDispData> productList) {
        this.context = context;
        this.productList = productList;
    }


    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ProductViewHolder(LayoutInflater.from(context).inflate(R.layout.item_product, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {

//        productDispData product = showProductdata.get(position).getData().get(position);
        productDispData product = productList.get(position);
        Glide.with(holder.binding.image.getContext())
                .load("http://192.168.1.17/ecommapi/admin/images/" + product.getPimage())
                .into(holder.binding.image);
        holder.binding.label.setText(product.getPname());
        holder.binding.price.setText(product.getCatname());
        holder.binding.price.setText("PKR " + product.getPrice());

//        Animation animation = AnimationUtils.loadAnimation(context, R.anim.fade_in);
//        holder.itemView.startAnimation(animation);

        holder.itemView.setAnimation(AnimationUtils.loadAnimation(context, R.anim.fade_in_animation));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ProductDetailActivity.class);
                intent.putExtra("name", product.getPname());
                intent.putExtra("image", product.getPimage());
                intent.putExtra("id", product.getId());
                intent.putExtra("price", product.getPrice());
                intent.putExtra("prodDetal", product.getPdesc());
                intent.putExtra("Pstock", product.getStock());
                context.startActivity(intent);


            }

        });
    }

    @Override
    public int getItemCount() {

        if (productList == null) {
            return 0;
        }
        return productList.size();

    }

    public class ProductViewHolder extends RecyclerView.ViewHolder {

        ItemProductBinding binding;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = ItemProductBinding.bind(itemView);
        }
    }
}
