package com.zohausman.mycandycotton.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.hishd.tinycart.model.Cart;
import com.hishd.tinycart.model.Item;
import com.hishd.tinycart.util.TinyCartHelper;
import com.zohausman.mycandycotton.R;
import com.zohausman.mycandycotton.adapter.ProductAdapter;
import com.zohausman.mycandycotton.apicontroller;
import com.zohausman.mycandycotton.databinding.ActivityProductDetailBinding;
import com.zohausman.mycandycotton.model.Showall;
import com.zohausman.mycandycotton.model.productDispData;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ProductDetailActivity extends AppCompatActivity {
ActivityProductDetailBinding binding;
productDispData currentProduct;

//++++++===
private ArrayList<productDispData> products;
    private ProductAdapter productAdapter;

    String selectedSize;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityProductDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
//        setContentView(R.layout.activity_product_detail);

        String name = getIntent().getStringExtra("name");
        String image = getIntent().getStringExtra("image");
        int id = getIntent().getIntExtra("id", 0);
        double price = getIntent().getDoubleExtra("price", 0);
        String detail = getIntent().getStringExtra("prodDetal");
        int Pstock = getIntent().getIntExtra("Pstock",0);

        Glide.with(this)
                .load("http://192.168.1.17/ecommapi/admin/images/"+image)
                .into(binding.productImage);
        binding.productDescription.setText(detail);
        binding.productPrice.setText(String.valueOf(price));

        getSupportActionBar().setTitle(name);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Cart cart = TinyCartHelper.getCart();
//        Toast.makeText(this, image, Toast.LENGTH_SHORT).show();
//        Toast.makeText(this, price, Toast.LENGTH_SHORT).show();


        //get the produt

       // Current
        currentProduct = new productDispData();
        currentProduct.setId(id);
        currentProduct.setPname(name);
        currentProduct.setPimage(image);
        currentProduct.setPrice(price);
        currentProduct.setPdesc(detail);
        currentProduct.setStock(Pstock);

        Toast.makeText(this, "price"+currentProduct.getPrice(), Toast.LENGTH_SHORT).show();

        // Initialize selectedSize with an empty string
        selectedSize = "";
        // Set the product price
        binding.buttonSmall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!selectedSize.equals("S")) {
                    selectedSize = "S";
                    updateButtonStates();
//                    v.setBackgroundColor(Color.WHITE);
                    ((Button) v).setTextColor(Color.YELLOW);
                    binding.buttonMedium.setVisibility(View.GONE);
                    binding.buttonLarge.setVisibility(View.GONE);
                    binding.buttonExtraLarge.setVisibility(View.GONE);
                }
            }
        });

        binding.buttonMedium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!selectedSize.equals("M")) {
                    selectedSize = "M";
                    updateButtonStates();
//                    v.setBackgroundColor(Color.WHITE);
                    ((Button) v).setTextColor(Color.YELLOW);
                    binding.buttonSmall.setVisibility(View.GONE);
                    binding.buttonLarge.setVisibility(View.GONE);
                    binding.buttonExtraLarge.setVisibility(View.GONE);
                }
            }
        });

        binding.buttonLarge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!selectedSize.equals("L")) {
                    selectedSize = "L";
                    updateButtonStates();
//                    v.setBackgroundColor(Color.WHITE);
                    ((Button) v).setTextColor(Color.YELLOW);
                    binding.buttonMedium.setVisibility(View.GONE);
                    binding.buttonSmall.setVisibility(View.GONE);
                    binding.buttonExtraLarge.setVisibility(View.GONE);
                }
            }
        });

        binding.buttonExtraLarge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!selectedSize.equals("XL")) {
                    selectedSize = "XL";
                    updateButtonStates();
//                    v.setBackgroundColor(Color.WHITE);
                    ((Button) v).setTextColor(Color.YELLOW);
                    binding.buttonLarge.setVisibility(View.GONE);
                    binding.buttonMedium.setVisibility(View.GONE);
                    binding.buttonSmall.setVisibility(View.GONE);

                }
            }
        });
        binding.addToCartBtn.setOnClickListener(new View.OnClickListener() {
            private View view;

            @Override
            public void onClick(View v) {
                if (selectedSize.isEmpty()) {
                    // Prompt the user to select a size
                    Toast.makeText(ProductDetailActivity.this, "Please select a size", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        Cart cart = TinyCartHelper.getCart();
                        currentProduct.setSize(selectedSize);
                        currentProduct.setPrice(price);

                        cart.addItem(currentProduct, 1);
                        Toast.makeText(ProductDetailActivity.this, "Product Added to cart", Toast.LENGTH_SHORT).show();
                        // Change the drawable image when the button is clicked
                        binding.addToCartBtn.setImageResource(R.drawable.ic_cart_white);
                        binding.addToCartBtn.setEnabled(false);
                        // Animation
                        Animation animation = AnimationUtils.loadAnimation(ProductDetailActivity.this, R.anim.circle_animation);
                        binding.gift.startAnimation(animation);
                        // Refresh button states and enable "Add to Cart" button again
//                        binding.buttonSmall.setVisibility(View.VISIBLE);
//                        binding.buttonMedium.setVisibility(View.VISIBLE);
//                        binding.buttonLarge.setVisibility(View.VISIBLE);
//                        binding.buttonExtraLarge.setVisibility(View.VISIBLE);
//                        binding.addToCartBtn.setEnabled(true);
//                        binding.addToCartBtn.setImageResource(R.drawable.ic_cart_pink);
//
//                        // Clear the selected size
//                        selectedSize = "";
//                        updateButtonStates();


//                        try {
//                            productDispData newProduct = new productDispData();
//                            newProduct.setId(currentProduct.getId());
//                            newProduct.setPname(currentProduct.getPname());
//                            newProduct.setPimage(currentProduct.getPimage());
//                            newProduct.setPrice(currentProduct.getPrice());
//                            newProduct.setPdesc(currentProduct.getPdesc());
//                            newProduct.setStock(currentProduct.getStock());
//                            newProduct.setSize(selectedSize);
//
//                            cart = TinyCartHelper.getCart();
//                            cart.addItem(newProduct, 1);

//                            Toast.makeText(ProductDetailActivity.this, "Product Added to cart", Toast.LENGTH_SHORT).show();
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                            Toast.makeText(ProductDetailActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
//                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(ProductDetailActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });


 // code that share the image in address
        binding.productShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder shareText = new StringBuilder();
                shareText.append("Image URL: ").append("http://192.168.1.16/ecommapi/admin/images/").append(currentProduct.getPimage()).append("\n");
                shareText.append("Product Name: ").append(currentProduct.getPname()).append("\n");
                shareText.append("Description: ").append(currentProduct.getPdesc()).append("\n");
                shareText.append("Size: ").append(currentProduct.getSize()).append("\n");
                shareText.append("Price: ").append(currentProduct.getPrice()).append("\n");

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareText.toString());

                v.getContext().startActivity(Intent.createChooser(shareIntent, "Share via"));
            }
        });
// coe that not work

//        binding.productShare.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                StringBuilder shareText = new StringBuilder();
//                shareText.append("Product Name: ").append(currentProduct.getPname()).append("\n");
//                shareText.append("Price: ").append(currentProduct.getPrice()).append("\n");
//                shareText.append("Size: ").append(currentProduct.getSize()).append("\n");
//
//                Intent shareIntent = new Intent(Intent.ACTION_SEND);
//                shareIntent.setType("text/plain");
//                shareIntent.putExtra(Intent.EXTRA_TEXT, shareText.toString());
//
//                // Check if the product has an image
//                if (currentProduct.getPimage() != null && !currentProduct.getPimage().isEmpty()) {
//                    try {
//                        // Load the image using Glide
//                        Bitmap bitmap = Glide.with(v.getContext())
//                                .asBitmap()
//                                .load("http://192.168.1.17/ecommapi/admin/images/" + currentProduct.getPimage())
//                                .submit()
//                                .get();
//
//                        // Create a temporary file to store the image
//                        File imageFile = new File(v.getContext().getCacheDir(), "shared_image.png");
//                        FileOutputStream outputStream = new FileOutputStream(imageFile);
//
//                        // Compress the bitmap to PNG format and save it to the file
//                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
//                        outputStream.flush();
//                        outputStream.close();
//
//                        // Get the image URI from the file
//                        Uri imageUri = FileProvider.getUriForFile(v.getContext(), v.getContext().getPackageName() + ".fileprovider", imageFile);
//
//                        // Add the image URI to the intent
//                        shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
//                        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//                        shareIntent.setType("image/png");
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                }
//
//                v.getContext().startActivity(Intent.createChooser(shareIntent, "Share via"));
//            }
//        });

    }



    private void updateButtonStates() {
        Button buttonSmall = findViewById(R.id.buttonSmall);
        Button buttonMedium = findViewById(R.id.buttonMedium);
        Button buttonLarge = findViewById(R.id.buttonLarge);
        Button buttonExtraLarge = findViewById(R.id.buttonExtraLarge);

        buttonSmall.setSelected(selectedSize.equals("S"));
        buttonMedium.setSelected(selectedSize.equals("M"));
        buttonLarge.setSelected(selectedSize.equals("L"));
        buttonExtraLarge.setSelected(selectedSize.equals("XL"));
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cart, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.cart) {
            try{
                startActivity(new Intent(this, CartActivity.class));

                Intent intent= new Intent(ProductDetailActivity.this, CartActivity.class);
                startActivity(intent);
            }catch(Exception e){
                e.printStackTrace();
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }


        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
    }
}
