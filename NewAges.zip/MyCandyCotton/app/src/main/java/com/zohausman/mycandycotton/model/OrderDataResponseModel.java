package com.zohausman.mycandycotton.model;

public class OrderDataResponseModel {
    public String order_id;
    public String inviceno;
    public String user_name;
    public String useremail;
    public String user_phone;
    public String user_address;
    public String user_city;
    public String user_id;
    public String order_status;
    public String date;
    public String order_tracking_id;

    public OrderDataResponseModel() {
    }

    public OrderDataResponseModel(String order_id, String inviceno, String user_name, String useremail, String user_phone, String user_address, String user_city, String user_id, String order_status, String date, String order_tracking_id) {
        this.order_id = order_id;
        this.inviceno = inviceno;
        this.user_name = user_name;
        this.useremail = useremail;
        this.user_phone = user_phone;
        this.user_address = user_address;
        this.user_city = user_city;
        this.user_id = user_id;
        this.order_status = order_status;
        this.date = date;
        this.order_tracking_id = order_tracking_id;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getInviceno() {
        return inviceno;
    }

    public void setInviceno(String inviceno) {
        this.inviceno = inviceno;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUseremail() {
        return useremail;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }

    public String getUser_phone() {
        return user_phone;
    }

    public void setUser_phone(String user_phone) {
        this.user_phone = user_phone;
    }

    public String getUser_address() {
        return user_address;
    }

    public void setUser_address(String user_address) {
        this.user_address = user_address;
    }

    public String getUser_city() {
        return user_city;
    }

    public void setUser_city(String user_city) {
        this.user_city = user_city;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getOrder_tracking_id() {
        return order_tracking_id;
    }

    public void setOrder_tracking_id(String order_tracking_id) {
        this.order_tracking_id = order_tracking_id;
    }
}
