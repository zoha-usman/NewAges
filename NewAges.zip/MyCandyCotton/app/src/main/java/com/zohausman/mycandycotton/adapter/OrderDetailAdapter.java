package com.zohausman.mycandycotton.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zohausman.mycandycotton.R;
import com.zohausman.mycandycotton.databinding.ItemsOrderBinding;
import com.zohausman.mycandycotton.model.OrderDataResponseModel;


import java.util.List;

public class OrderDetailAdapter extends RecyclerView.Adapter<OrderDetailAdapter.ViewHolder> {

   private Context context;
    private List<OrderDataResponseModel> orders;



    public OrderDetailAdapter(Context context, List<OrderDataResponseModel> orders){
        this.context =context;
        this.orders = orders;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.items_order, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Bind data to the views in the ViewHolder
        OrderDataResponseModel order = orders.get(position);
         holder.binding.CName.setText(order.getUser_name());
         holder.binding.CEmail.setText(order.getUseremail());
         holder.binding.CPhone.setText(order.getUser_phone());
         holder.binding.CAddress.setText(order.getUser_address());
         holder.binding.orderId.setText(order.getOrder_id());
         holder.binding.COrderStatus.setText(order.getOrder_status());
         holder.binding.CInvoiceNo.setText(order.getInviceno());
//         holder.binding.CEmail.setText(order.getUseremail());


//        holder.Cname.setText(order.getUser_name());
//        holder.Cemail.setText(order.getUseremail());
//        holder.Caddress.setText(order.getUser_address());
//        holder.Cphone.setText(order.getUser_phone());
//        holder.CorderId.setText(order.getOrder_id());
//        holder.CorderStatus.setText(order.getOrder_status());
//        holder.CinvoiceNo.setText(order.getInviceno());
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        // Declare your views here
//        TextView Cname, Cemail, Caddress,Cphone, CorderId, CorderStatus, CinvoiceNo;

        ItemsOrderBinding binding;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
                   binding = ItemsOrderBinding.bind(itemView);
//            Cname = itemView.findViewById(R.id.C_name);
//            Cemail = itemView.findViewById(R.id.C_name);
//            Caddress = itemView.findViewById(R.id.C_name);
//            Cphone = itemView.findViewById(R.id.C_name);
//            CorderId = itemView.findViewById(R.id.C_name);
//            CorderStatus = itemView.findViewById(R.id.C_name);
//            CinvoiceNo = itemView.findViewById(R.id.C_name);

        }

    }
}
