package com.zohausman.mycandycotton.model;

public class login_response_model
{
    public String msg;
    public boolean status;
    public String action;
    public Data data;

    public login_response_model() {
    }

    public login_response_model(String msg, boolean status, String action, Data data) {
        this.msg = msg;
        this.status = status;
        this.action = action;
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }
}

