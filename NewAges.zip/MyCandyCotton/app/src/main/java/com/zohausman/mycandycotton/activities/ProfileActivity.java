package com.zohausman.mycandycotton.activities;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import com.zohausman.mycandycotton.apicontroller;
import com.zohausman.mycandycotton.databinding.ActivityProfileBinding;
import com.zohausman.mycandycotton.model.ApiResponseProfileUPdate;
import com.zohausman.mycandycotton.model.profile_pic_update;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;



public class ProfileActivity extends AppCompatActivity {
    ActivityProfileBinding binding;
    String UserID;
    private String imageBase64;

    public Bitmap imageBitmap;
    // Define a constant to use as the request code
    static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_IMAGE_GALLERY = 2;
    private File uploadedImageFile;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);

//         setContentView(R.layout.activity_profile);


        SharedPreferences sp = getSharedPreferences("credentials", MODE_PRIVATE);
        String userId = sp.getString("userid", UserID);
        String fullName = sp.getString("username", "");
        String email = sp.getString("useremail", "");
        String password = sp.getString("password", "");
        String contact = sp.getString("contact", "");
        String address = sp.getString("address", "");
        String city = sp.getString("city", "");
        Toast.makeText(this, "userId:" + userId, Toast.LENGTH_SHORT).show();


        // Bind data to corresponding views
        binding.fullNameProfile.setText(fullName);
        binding.EmailProfile.setText(email);
        binding.PasswordProfile.setText(password);
        binding.contactNunber.setText(contact);
        binding.Address.setText(address);
        binding.City.setText(city);


        // Set click listener for the update button
        binding.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleUpdateProfile();
            }
        });


        // for image

        clickListeners();


    }

    private void clickListeners() {

        binding.cameraButton.setOnClickListener(v -> {
            CamGellaryAlert();
        });
        binding.profileImage.setOnClickListener(v -> {

            // Call Method to open camera
            dispatchTakePictureIntent();

        });


        // button to save upoad the image
        binding.btnuploadImage.setOnClickListener(v -> {
            try {

                hitMarkAttendanceAPI();

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }

        });

    }

    private void CamGellaryAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(ProfileActivity.this);
        builder.setTitle("Choose Avatar Source");
        String[] avatarSources = {"Camera", "Gallery"};
        builder.setItems(avatarSources, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        dispatchTakePictureIntent();
                        break;
                    case 1:
                        openGallery();
                        break;

                }
            }
        });
        builder.show();

    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_IMAGE_GALLERY);
    }


    private void dispatchTakePictureIntent() {
        // Create an intent to launch the camera app
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        // Check if the device has a camera app
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Start the camera app
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
                Bundle extras = data.getExtras();
                imageBitmap = (Bitmap) extras.get("data");
                saveImageToLocalStorage(imageBitmap);
                binding.profileImage.setImageBitmap(imageBitmap);

//                Bundle extras = data.getExtras();
//                imageBitmap = (Bitmap) extras.get("data");
//
//                File des = null;
//
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
//                    des = new File(this.getExternalFilesDir(null)
//                            + "/RLT");
//                } else {
//                    des = new File(Environment.getExternalStorageDirectory() +
//                            "/RLT");
//                }
//                if (!des.exists()) {
//                    des.mkdir();
//                }
//
//                saveImageToLocalStorage(imageBitmap, des);

            } else if (requestCode == REQUEST_IMAGE_GALLERY && resultCode == RESULT_OK) {
                Uri imageUri = data.getData();
                try {
                    imageBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                    saveImageToLocalStorage(imageBitmap);
                    binding.profileImage.setImageBitmap(imageBitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void saveImageToLocalStorage(Bitmap imageBitmap) {
        File directory;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            directory = new File(this.getExternalFilesDir(null) + "/RLT");
        } else {
            directory = new File(Environment.getExternalStorageDirectory() + "/RLT");
        }
        if (!directory.exists()) {
            directory.mkdir();
        }
        imageFile = new File(directory, "profile_image.png");
        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            imageBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    private void hitMarkAttendanceAPI() {

        if (imageBitmap == null) {
            Toast.makeText(this, "Please take a picture", Toast.LENGTH_SHORT).show();
            return;
        }


        File des;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            des = new File(this.getExternalFilesDir(null)
                    + "/RLT");
        } else {
            des = new File(Environment.getExternalStorageDirectory() +
                    "/RLT");
        }


//            ArrayList<File> inFiles = new ArrayList<File>();
//            File[] files = des.listFiles();
//            if (files != null) {
//                for (File file : files) {
//                    inFiles.add(file);
//                }
//            } else {
//
//
//            }
//        File file = inFiles.get(0);
//        Glide
//                .with(ProfileActivity.this)
//                .load(file)
//                .into(binding.profileImage);

        File[] files = des.listFiles();
            if(files != null && files.length >0) {
                // Sort the files based on last modified time in descending order
                Arrays.sort(files, new Comparator<File>() {
                    public int compare(File f1, File f2) {
                        return Long.compare(f2.lastModified(), f1.lastModified());
                    }
                });


                uploadedImageFile = files[0];
                Glide.with(ProfileActivity.this)
                        .load(uploadedImageFile.getAbsolutePath()) // Provide the image file path
                        .into(binding.profileImage);

            }  else{
                // No images found in the directory
                // You can set a default profile image or show an error message
                Toast.makeText(ProfileActivity.this, "No images found", Toast.LENGTH_SHORT).show();

            }


//       .load(file.getAbsolutePath())

    RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), uploadedImageFile);
    MultipartBody.Part body = MultipartBody.Part.createFormData("img", uploadedImageFile.getName(), requestBody);

    RequestBody action = RequestBody.create(MediaType.parse("text/plain"), "profile_pic_update");

    RequestBody user_id = RequestBody.create(MediaType.parse("text/plain"), getUserIdFromSharedPreferences());

          final Call<profile_pic_update> response = apicontroller.getInstance().getapiSet().upload( action ,user_id, body);
            response.enqueue(new Callback<profile_pic_update>() {
                @Override
                public void onResponse(Call<profile_pic_update> call, Response<profile_pic_update> response) {

                    if (response.isSuccessful()) {
                        profile_pic_update obj = response.body();
                        if (obj != null) {
                            Toast.makeText(ProfileActivity.this, obj.getMsg(), Toast.LENGTH_SHORT).show();

                            // Delete the uploaded image file
                            if (uploadedImageFile != null && uploadedImageFile.exists()) {
                                uploadedImageFile.delete();
                            }



//                             Set the latest captured image as the profile image
                            // With this line
                            Glide.with(ProfileActivity.this)
                                    .load(uploadedImageFile.getAbsolutePath()) // Provide the image file path
                                    .into(binding.profileImage);



                        } else {
                            Toast.makeText(ProfileActivity.this, "Failed to update profile picture", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(ProfileActivity.this, "API Error: " + response.message(), Toast.LENGTH_SHORT).show();
                    }

                }

                @Override
                public void onFailure(Call<profile_pic_update> call, Throwable t) {
                    Toast.makeText(ProfileActivity.this, "Failed. " + t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });


        }




    private File imageFile; // Declare the imageFile variable


    @RequiresApi(api = Build.VERSION_CODES.O)
    private void saveImageToLocalStorage(Bitmap imageBitmap, File directory) {

        // Create a file to save the image
        File file = new File(directory, "selfie.png");
//        imageFile = new File(directory, "NewSelfie.png");

        // Write the bitmap to the file
        try (FileOutputStream fos = new FileOutputStream(file)) {

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            imageBitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
            byte[] imageBytes = baos.toByteArray();
            fos.write(imageBytes);




        } catch (IOException e) {
            e.printStackTrace();
        }


    }




//++++++++++++++++++++++++++++++++for Update the other data of user
    private void handleUpdateProfile() {
        // Get the updated profile data from the views
        String userId = getUserIdFromSharedPreferences();
        String name = binding.fullNameProfile.getText().toString();
        String email = binding.EmailProfile.getText().toString();
        String password = binding.PasswordProfile.getText().toString();
        String address = binding.Address.getText().toString();
        String city = binding.City.getText().toString();
        String contact = binding.contactNunber.getText().toString();

        // Call the method to update the user profile
        updateUserProfile(userId, name, email, password, address, city, contact);
    }

    private String getUserIdFromSharedPreferences() {
        // Implement this method to retrieve the user ID from SharedPreferences
        SharedPreferences sp = getSharedPreferences("credentials", MODE_PRIVATE);
        return sp.getString("userid", "");
    }

    private String getPasswordFromSharedPreferences() {
        // method to retrieve the password from SharedPreferences
        SharedPreferences sp = getSharedPreferences("credentials", MODE_PRIVATE);
        return sp.getString("password", "");
    }

    private void updateUserProfile(String userId, String name, String email, String password, String address, String city, String contact) {
        // to update the user profile using the provided data
        // checkProfileUpdate method here
        checkProfileUpdate(userId, name, email, password, address, city, contact);
    }

    private void checkProfileUpdate(String userId, String name, String email, String password, String address, String city, String contact) {

        Call<ApiResponseProfileUPdate> call = apicontroller.getInstance().getapiSet().checkProfileUpdate(userId, name, email, password, address, city, contact);
        call.enqueue(new Callback<ApiResponseProfileUPdate>() {
            @Override
            public void onResponse(Call<ApiResponseProfileUPdate> call, Response<ApiResponseProfileUPdate> response) {
                if (response.isSuccessful()) {
                    ApiResponseProfileUPdate result = response.body();
                    // Handle the response accordingly
                    if (result != null && result.isStatus()) {
                        // Profile was updated
                        Toast.makeText(ProfileActivity.this, "Profile was updated", Toast.LENGTH_SHORT).show();
                    } else {
                        // Profile was not updated
                        Toast.makeText(ProfileActivity.this, "Profile was not updated", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Handle API error
                    Toast.makeText(ProfileActivity.this, "API Error: " + response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ApiResponseProfileUPdate> call, Throwable t) {
                // Handle network or unexpected errors
                Toast.makeText(ProfileActivity.this, "Failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }





}


