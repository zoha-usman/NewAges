package com.zohausman.mycandycotton.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.transition.Slide;
import android.view.View;

import com.zohausman.mycandycotton.databinding.ActivitySliderBinding;

import org.imaginativeworld.whynotimagecarousel.model.CarouselItem;

public class SliderActivity extends AppCompatActivity {
  ActivitySliderBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySliderBinding.inflate(getLayoutInflater());
//        binding = ActivitySliderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

//        setContentView(R.layout.activity_slider);

        initSlider();
        binding.getStarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SliderActivity.this, DashBoard.class);
                startActivity(intent);
            }
        });



    }


    private void initSlider() {
        binding.carouselSlider.addData(new CarouselItem("https://www.shutterstock.com/image-photo/fashion-style-panoramic-full-body-260nw-1953688732.jpg", "Slider 1"));
        binding.carouselSlider.addData(new CarouselItem("https://www.shutterstock.com/image-photo/fashion-style-panoramic-full-body-260nw-1953688732.jpg", "Slider 1"));
        binding.carouselSlider.addData(new CarouselItem("https://www.shutterstock.com/image-photo/fashion-style-panoramic-full-body-260nw-1953688732.jpg", "Slider 1"));
        binding.carouselSlider.addData(new CarouselItem("https://www.shutterstock.com/image-photo/fashion-style-panoramic-full-body-260nw-1953688732.jpg", "Slider 1"));
    }

}