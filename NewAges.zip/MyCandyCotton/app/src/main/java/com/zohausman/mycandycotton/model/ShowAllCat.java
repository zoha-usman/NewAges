package com.zohausman.mycandycotton.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ShowAllCat {

    @SerializedName("data")
    public ArrayList<Category> data;
    public String msg;
    public boolean sts;
    public String action;


    public ShowAllCat() {
    }

    public ShowAllCat(String msg, boolean sts, String action, ArrayList<Category> data) {
        this.msg = msg;
        this.sts = sts;
        this.action = action;
        this.data = data;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isSts() {
        return sts;
    }

    public void setSts(boolean sts) {
        this.sts = sts;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public ArrayList<Category> getData() {
        return data;
    }

    public void setData(ArrayList<Category> data) {
        this.data = data;
    }
}
